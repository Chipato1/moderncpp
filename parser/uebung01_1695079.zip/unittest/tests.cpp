#include "../Include/OptParser.h"
#include "catch.hpp"

TEST_CASE("Return true for correct Statements.")
{

    char a1[] = "AppName";
    char a2[] = "-x";
    char a3[] = "-y=WERT";
    char a4[] = "-zWERT";
    char a5[] = "-k";
    char a6[] = "WERT";

    char a7[] = "W1R3";
    char a8[] = "-zW?R2";
    char a9[] = "-x=??34";

    char *string1_b[]		= {a1, a2, a3, a4, a5, a6};
    char* string2_b[]       = {a1, a3, a2, a2, a6, a5};

    char* string1_s[]       = {a1, a2};
    char* string2_s[]       = {a1, a3};
    char* string3_s[]       = {a1, a4};
    char* string4_s[]       = {a1, a5};

    char* string1_c[]       = {a1, a2, a7};
    char* string2_c[]       = {a1, a8};
    char* string3_c[]       = {a1, a9};
    char* string4_c[]       = {a1, a2, a7, a8};

    CmdLineOptParser testParser;

    SECTION("The Parse is abled to Parse small Strings.")
    {
        REQUIRE(testParser.Parse(2, string1_s) == true);
        REQUIRE(testParser.Parse(2, string2_s) == true);
        REQUIRE(testParser.Parse(2, string3_s) == true);
        REQUIRE(testParser.Parse(2, string4_s) == true);
    }
    SECTION("Values can be all characters.") { 
		REQUIRE(testParser.Parse(3, string1_c) == true);
        REQUIRE(testParser.Parse(2, string2_c) == true);
        REQUIRE(testParser.Parse(2, string3_c) == true);
        REQUIRE(testParser.Parse(4, string4_c) == true);
	}
    SECTION("The Parse is abled to Parse big Strings.")
    {
        REQUIRE(testParser.Parse(6, string1_b) == true);
        REQUIRE(testParser.Parse(6, string2_b) == true);
    }
}

TEST_CASE("return false for incorrect Statements")
{
    CmdLineOptParser testParser;

    char  a1[]      = "AppName";

    char  a2[]		= "xk";
    char  a3[]      = "?y=WERT";
    char  a4[]      = "1zWERT";
	
	char  a5[]      = "-?";
    char  a6[]      = "--WERT";
    char  a7[]      = "-|=WERT";

    char  a8[]      = "WERT";
    char  a9[]      = "-x";
	
	char* string1_a[] = {a1, a2};
    char* string2_a[] = {a1, a3};
    char* string3_a[] = {a1, a4};

	char* string1_b[] = {a1, a5};
    char* string2_b[] = {a1, a6};
    char* string3_b[] = {a1, a7};

	char* string1_c[] = {a1, a8};
    char* string2_c[] = {a1, a9, a8, a8};
    char* string3_c[] = {a1, a8, a9};

	SECTION("Strings can not start with another char than '-'.") { 
		REQUIRE(testParser.Parse(2, string1_a) == false);
        REQUIRE(testParser.Parse(2, string2_a) == false);
        REQUIRE(testParser.Parse(2, string3_a) == false);
	}

    SECTION("The first character after '-' can only be a letter.") { 
		REQUIRE(testParser.Parse(2, string1_b) == false);
        REQUIRE(testParser.Parse(2, string2_b) == false);
        REQUIRE(testParser.Parse(2, string3_b) == false);
	}

    SECTION("Values need to be arranged correct.") { 
		REQUIRE(testParser.Parse(2, string1_c) == false);
        REQUIRE(testParser.Parse(4, string2_c) == false);
        REQUIRE(testParser.Parse(3, string3_c) == false);
	}

}