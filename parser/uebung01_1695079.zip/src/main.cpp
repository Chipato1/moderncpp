#include "OptParser.h"
#include <iostream>
int main(int argc, char* argv[]) {

	CmdLineOptParser cmdparse;

	if (cmdparse.Parse(argc, argv) == true) {
		std::cout << "Erfolgreich"<< std::endl;;
	}else{
		std::cout << "nicht Erfolgreich"<< std::endl;;
	}
}